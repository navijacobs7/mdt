A Pen created at CodePen.io. You can find this one at http://codepen.io/rgg/pen/dMEyvQ.

 A cool SVG + CSS effect for charts